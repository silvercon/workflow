package com.newfiber.workflow.parent.entity.request;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * 修改巡查申请
 *
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
@Data
public class PatrolApplyModifyReq {

  /** 编号 */
  @NotNull(message = "id不能为空")
  @ApiModelProperty(name = "id", value = "编号")
  private Integer id;

  /** 工作流实例编号 */
  @ApiModelProperty(name = "workflowInstanceId", value = "工作流实例编号")
  private String workflowInstanceId;

  /** 状态 */
  @ApiModelProperty(name = "status", value = "状态")
  private String status;

  /** 申请说明 */
  @ApiModelProperty(name = "applyNote", value = "申请说明")
  private String applyNote;

  /** 申请时间 */
  @ApiModelProperty(name = "applyDatetime", value = "申请时间")
  private String applyDatetime;
}
