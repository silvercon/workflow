package com.newfiber.workflow.parent.entity.request;

import com.newfiber.workflow.support.request.WorkflowStartReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 新增会签
 *
 * @author : xiongk
 * @since : 2021-08-23 09:52
 */
@Data
public class CountersignCreateReq extends WorkflowStartReq {

  /** 申请说明 */
  @ApiModelProperty(name = "applyNote", value = "申请说明")
  private String applyNote;
}
