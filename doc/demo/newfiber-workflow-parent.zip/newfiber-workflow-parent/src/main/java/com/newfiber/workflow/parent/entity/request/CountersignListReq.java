package com.newfiber.workflow.parent.entity.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 列表查询会签
 *
 * @author : xiongk
 * @since : 2021-08-23 09:52
 */
@Data
public class CountersignListReq {

  /** 编号 */
  @ApiModelProperty(name = "id", value = "编号")
  private Integer id;

  /** 工作流实例编号 */
  @ApiModelProperty(name = "workflowInstanceId", value = "工作流实例编号")
  private String workflowInstanceId;

  /** 状态 */
  @ApiModelProperty(name = "status", value = "状态")
  private String status;
}
