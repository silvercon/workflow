package com.newfiber.workflow.parent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.newfiber.workflow.parent", "com.newfiber.workflow"})
public class WorkflowParentApplication {

  public static void main(String[] args) {
    SpringApplication.run(WorkflowParentApplication.class, args);
  }
}
