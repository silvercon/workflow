package com.newfiber.workflow.parent.entity.request;

import com.newfiber.workflow.support.request.WorkflowStartReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 新增巡查申请
 *
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
@Data
public class PatrolApplyCreateReq extends WorkflowStartReq {

    /**
     * 申请说明
     */
    @ApiModelProperty(name = "applyNote", value = "申请说明")
    private String applyNote;

}
