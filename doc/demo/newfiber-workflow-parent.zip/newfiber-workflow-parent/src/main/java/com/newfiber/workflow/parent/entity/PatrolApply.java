package com.newfiber.workflow.parent.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.Data;

/**
 * 巡查申请
 *
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
@Data
@TableName("biz_patrol_apply")
public class PatrolApply {

  /** 编号 */
  @TableId(type = IdType.AUTO)
  @ApiModelProperty(name = "id", value = "编号", position = 10)
  private Integer id;

  /** 工作流实例编号 */
  @ApiModelProperty(name = "workflowInstanceId", value = "工作流实例编号", position = 20)
  private String workflowInstanceId;

  /** 状态 */
  @ApiModelProperty(name = "status", value = "状态", position = 30)
  private String status;

  /** 申请说明 */
  @ApiModelProperty(name = "applyNote", value = "申请说明", position = 40)
  private String applyNote;

  /** 申请时间 */
  @ApiModelProperty(name = "applyDatetime", value = "申请时间", position = 50)
  private Date applyDatetime;
}
