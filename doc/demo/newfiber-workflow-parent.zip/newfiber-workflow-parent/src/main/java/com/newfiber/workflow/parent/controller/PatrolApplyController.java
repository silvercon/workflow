package com.newfiber.workflow.parent.controller;

import com.newfiber.core.result.PageInfo;
import com.newfiber.core.result.Result;
import com.newfiber.core.result.ResultCode;
import com.newfiber.workflow.parent.entity.PatrolApply;
import com.newfiber.workflow.parent.entity.request.PatrolApplyApproveReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyCreateReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyListReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyModifyReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyPageReq;
import com.newfiber.workflow.parent.service.PatrolApplyService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import javax.annotation.Resource;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 巡查申请Controller
 *
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
@RestController
@Api(value = "BIZ01-巡查申请管理", tags = "BIZ01-巡查申请管理")
@RequestMapping("/patrol_apply")
public class PatrolApplyController {

  @Resource private PatrolApplyService patrolApplyService;

  @ApiOperation(value = "新增巡查申请对象", position = 10)
  @PostMapping(value = "/create")
  public Result<Object> create(@RequestBody @Valid PatrolApplyCreateReq request) {
    patrolApplyService.create(request);
    return new Result<>(ResultCode.SUCCESS);
  }

  @ApiOperation(value = "删除巡查申请对象", position = 20)
  @PostMapping("/remove/{id}")
  public Result<Object> remove(@PathVariable("id") @Valid Integer id) {
    patrolApplyService.remove(id);
    return new Result<>(ResultCode.SUCCESS);
  }

  @ApiOperation(value = "修改巡查申请对象", position = 30)
  @PostMapping(value = "/modify")
  public Result<Object> modify(@RequestBody @Valid PatrolApplyModifyReq request) {
    patrolApplyService.modify(request);
    return new Result<>(ResultCode.SUCCESS);
  }

  @ApiOperation(value = "审核巡查申请对象", position = 30)
  @PostMapping(value = "/approve")
  public Result<Object> approve(@RequestBody @Valid PatrolApplyApproveReq request) {
    patrolApplyService.approve(request);
    return new Result<>(ResultCode.SUCCESS);
  }

  @ApiOperation(value = "查询巡查申请对象", position = 40)
  @PostMapping("/detail/{id}")
  public Result<PatrolApply> detail(@PathVariable("id") @Valid Integer id) {
    return new Result<>(ResultCode.SUCCESS, patrolApplyService.detail(id));
  }

  @ApiOperation(value = "分页条件查询巡查申请", position = 50)
  @PostMapping(value = "/page")
  public Result<PageInfo<PatrolApply>> page(@RequestBody @Valid PatrolApplyPageReq request) {
    return new Result<>(ResultCode.SUCCESS, patrolApplyService.page(request));
  }

  @ApiOperation(value = "列表条件查询巡查申请", position = 70)
  @PostMapping(value = "/list")
  public Result<List<PatrolApply>> list(@RequestBody @Valid PatrolApplyListReq request) {
    return new Result<>(ResultCode.SUCCESS, patrolApplyService.list(request));
  }
}
