package com.newfiber.workflow.parent.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.newfiber.workflow.entity.support.WorkflowCountersignUser;
import com.newfiber.workflow.support.page.result.WorkflowPageResult;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import java.util.List;
import lombok.Data;

/**
 * 会签
 *
 * @author : xiongk
 * @since : 2021-08-23 09:52
 */
@Data
@TableName("biz_countersign")
public class Countersign implements WorkflowPageResult {

  /** 编号 */
  @TableId(type = IdType.AUTO)
  @ApiModelProperty(name = "id", value = "编号", position = 10)
  private Integer id;

  /** 工作流实例编号 */
  @ApiModelProperty(name = "workflowInstanceId", value = "工作流实例编号", position = 20)
  private String workflowInstanceId;

  /** 状态 */
  @ApiModelProperty(name = "status", value = "状态", position = 30)
  private String status;

  /** 申请说明 */
  @ApiModelProperty(name = "applyNote", value = "申请说明", position = 40)
  private String applyNote;

  /** 申请时间 */
  @ApiModelProperty(name = "applyDatetime", value = "申请时间", position = 50)
  private Date applyDatetime;

  // ********* DB Properties

  /** 工作流会签用户 */
  @ApiModelProperty(name = "工作流会签用户", value = "工作流会签用户", position = 50)
  private List<WorkflowCountersignUser> countersignUserList;
}
