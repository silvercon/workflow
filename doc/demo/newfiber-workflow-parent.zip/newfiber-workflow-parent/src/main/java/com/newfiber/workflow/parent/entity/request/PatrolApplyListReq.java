package com.newfiber.workflow.parent.entity.request;

import com.newfiber.workflow.support.request.WorkflowListReq;
import lombok.Data;

/**
 * 列表查询巡查申请
 *
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
@Data
public class PatrolApplyListReq extends WorkflowListReq {



}
