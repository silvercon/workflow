package com.newfiber.workflow.parent.entity.request;

import com.newfiber.workflow.support.request.WorkflowPageReq;
import lombok.Data;

/**
 * 分页查询巡查申请
 *
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
@Data
public class PatrolApplyPageReq extends WorkflowPageReq {}
