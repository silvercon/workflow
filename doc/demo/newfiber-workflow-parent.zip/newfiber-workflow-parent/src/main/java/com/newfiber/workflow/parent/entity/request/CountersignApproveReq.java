package com.newfiber.workflow.parent.entity.request;

import com.newfiber.workflow.support.request.WorkflowSubmitReq;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
@Data
public class CountersignApproveReq extends WorkflowSubmitReq {

  /** 编号 */
  @NotNull
  @ApiModelProperty(name = "id", value = "编号", position = 10, required = true)
  private Integer id;
}
