package com.newfiber.workflow.parent.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.newfiber.core.result.PageInfo;
import com.newfiber.workflow.parent.dao.CountersignDao;
import com.newfiber.workflow.parent.entity.Countersign;
import com.newfiber.workflow.parent.entity.request.CountersignApproveReq;
import com.newfiber.workflow.parent.entity.request.CountersignCreateReq;
import com.newfiber.workflow.parent.entity.request.CountersignListReq;
import com.newfiber.workflow.parent.entity.request.CountersignModifyReq;
import com.newfiber.workflow.parent.entity.request.CountersignPageReq;
import com.newfiber.workflow.parent.enums.ECountersignNotification;
import com.newfiber.workflow.parent.enums.EWorkflowDefinition;
import com.newfiber.workflow.parent.service.CountersignService;
import com.newfiber.workflow.service.ActivitiProcessService;
import com.newfiber.workflow.support.IWorkflowCallback;
import com.newfiber.workflow.support.IWorkflowDefinition;
import com.newfiber.workflow.support.notification.IWorkflowNotification;
import com.newfiber.workflow.support.page.WorkflowPageHelper;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 会签ServiceImpl
 *
 * @author : xiongk
 * @since : 2021-08-23 09:52
 */
@Service
public class CountersignServiceImpl extends ServiceImpl<CountersignDao, Countersign> implements
        CountersignService, IWorkflowCallback<Countersign> {

    @Resource
    private CountersignDao countersignDao;

    @Resource
    private ActivitiProcessService activitiProcessService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void create(CountersignCreateReq req) {
        Countersign countersign = new Countersign();
        BeanUtils.copyProperties(req, countersign);
        countersign.setApplyDatetime(new Date());
        this.save(countersign);

        activitiProcessService.startWorkflow(this, countersign.getId(), req);
    }

    @Override
    public void remove(Integer id) {
        this.removeById(id);
    }

    @Override
    public void modify(CountersignModifyReq req) {
        Countersign countersign = new Countersign();
        BeanUtils.copyProperties(req, countersign);

        this.updateById(countersign);
    }

    @Override
    public void approve(CountersignApproveReq req) {
        activitiProcessService.submitWorkflow(this, req.getId(), req);
    }

    @Override
    public Countersign detail(Integer id) {
        return this.getById(id);
    }

    @Override
    public PageInfo<Countersign> page(CountersignPageReq req) {
        Countersign condition = new Countersign();
        BeanUtils.copyProperties(req, condition);
        WorkflowPageHelper.startPage(req, this);

        List<Countersign> list = countersignDao.selectByCondition(condition);
        return new PageInfo<>(list);
    }

    @Override
    public List<Countersign> list(CountersignListReq req) {
        Countersign condition = new Countersign();
        BeanUtils.copyProperties(req, condition);

        return countersignDao.selectByCondition(condition);
    }

    @Override
    public IWorkflowDefinition getWorkflowDefinition() {
        return EWorkflowDefinition.Countersign;
    }

    @Override
    public void refreshWorkflowInstanceId(Object businessKey, String workflowInstanceId) {
        Countersign condition = new Countersign();
        condition.setId(Integer.parseInt(businessKey.toString()));
        condition.setWorkflowInstanceId(workflowInstanceId);
        updateById(condition);
    }

    @Override
    public void refreshStatus(Object businessKey, String status) {
        Countersign condition = new Countersign();
        condition.setId(Integer.parseInt(businessKey.toString()));
        condition.setStatus(status);
        updateById(condition);
    }

    @Override
    public IWorkflowNotification[] getWorkflowNotification() {
        return ECountersignNotification.values();
    }
}
