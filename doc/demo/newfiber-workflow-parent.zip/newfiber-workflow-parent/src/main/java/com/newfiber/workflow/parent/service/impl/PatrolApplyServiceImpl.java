package com.newfiber.workflow.parent.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.newfiber.core.result.PageInfo;
import com.newfiber.workflow.parent.dao.PatrolApplyDao;
import com.newfiber.workflow.parent.entity.PatrolApply;
import com.newfiber.workflow.parent.entity.request.PatrolApplyApproveReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyCreateReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyListReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyModifyReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyPageReq;
import com.newfiber.workflow.parent.enums.EWorkflowDefinition;
import com.newfiber.workflow.parent.service.PatrolApplyService;
import com.newfiber.workflow.service.ActivitiProcessService;
import com.newfiber.workflow.support.IWorkflowCallback;
import com.newfiber.workflow.support.IWorkflowDefinition;
import com.newfiber.workflow.support.page.WorkflowPageHelper;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 巡查申请ServiceImpl
 *
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
@Service
public class PatrolApplyServiceImpl extends ServiceImpl<PatrolApplyDao, PatrolApply>
    implements PatrolApplyService, IWorkflowCallback<PatrolApply> {

  @Resource private PatrolApplyDao patrolApplyDao;

  @Resource private ActivitiProcessService activitiProcessService;

  @Override
  @Transactional(rollbackFor = Exception.class)
  public void create(PatrolApplyCreateReq req) {
    PatrolApply patrolApply = new PatrolApply();
    BeanUtils.copyProperties(req, patrolApply);
    patrolApply.setApplyDatetime(new Date());
    this.save(patrolApply);

    activitiProcessService.startWorkflow(this, patrolApply.getId(), req);
  }

  @Override
  public void remove(Integer id) {
    this.removeById(id);
  }

  @Override
  public void modify(PatrolApplyModifyReq req) {
    PatrolApply patrolApply = new PatrolApply();
    BeanUtils.copyProperties(req, patrolApply);

    this.updateById(patrolApply);
  }

  @Override
  public void approve(PatrolApplyApproveReq req) {
    activitiProcessService.submitWorkflow(this, req.getId(), req);
  }

  @Override
  public PatrolApply detail(Integer id) {
    return this.getById(id);
  }

  @Override
  public PageInfo<PatrolApply> page(PatrolApplyPageReq req) {
    PatrolApply condition = new PatrolApply();
    BeanUtils.copyProperties(req, condition);
    WorkflowPageHelper.startPage(req, this);

    List<PatrolApply> list = patrolApplyDao.selectByCondition(condition);
    return new PageInfo<>(list);
  }

  @Override
  public List<PatrolApply> list(PatrolApplyListReq req) {
    PatrolApply condition = new PatrolApply();
    BeanUtils.copyProperties(req, condition);

    return patrolApplyDao.selectByCondition(condition);
  }

  @Override
  public IWorkflowDefinition getWorkflowDefinition() {
    return EWorkflowDefinition.PatrolApply;
  }

  @Override
  public void refreshWorkflowInstanceId(Object businessKey, String workflowInstanceId) {
    PatrolApply condition = new PatrolApply();
    condition.setId(Integer.parseInt(businessKey.toString()));
    condition.setWorkflowInstanceId(workflowInstanceId);
    updateById(condition);
  }

  @Override
  public void refreshStatus(Object businessKey, String status) {
    PatrolApply condition = new PatrolApply();
    condition.setId(Integer.parseInt(businessKey.toString()));
    condition.setStatus(status);
    updateById(condition);
  }
}
