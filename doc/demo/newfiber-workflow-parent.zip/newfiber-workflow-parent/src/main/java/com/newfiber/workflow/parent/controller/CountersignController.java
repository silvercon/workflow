package com.newfiber.workflow.parent.controller;

import com.newfiber.core.result.PageInfo;
import com.newfiber.core.result.Result;
import com.newfiber.core.result.ResultCode;
import com.newfiber.workflow.parent.entity.Countersign;
import com.newfiber.workflow.parent.entity.request.CountersignApproveReq;
import com.newfiber.workflow.parent.entity.request.CountersignCreateReq;
import com.newfiber.workflow.parent.entity.request.CountersignListReq;
import com.newfiber.workflow.parent.entity.request.CountersignModifyReq;
import com.newfiber.workflow.parent.entity.request.CountersignPageReq;
import com.newfiber.workflow.parent.service.CountersignService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import javax.annotation.Resource;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 会签Controller
 *
 * @author : xiongk
 * @since : 2021-08-23 09:52
 */
@RestController
@Api(value = "BIZ02-会签管理", tags = "BIZ02-会签管理")
@RequestMapping("/countersign")
public class CountersignController{

    @Resource
    private CountersignService countersignService;

    @ApiOperation(value = "新增会签对象", position = 10)
    @PostMapping(value = "/create")
    public Result<Object> create(@RequestBody @Valid CountersignCreateReq request) {
        countersignService.create(request);
        return new Result<>(ResultCode.SUCCESS);
    }

    @ApiOperation(value = "删除会签对象", position = 20)
    @PostMapping("/remove/{id}")
    public Result<Object> remove(@PathVariable("id") @Valid Integer id) {
        countersignService.remove(id);
        return new Result<>(ResultCode.SUCCESS);
    }

    @ApiOperation(value = "修改会签对象", position = 30)
    @PostMapping(value = "/modify")
    public Result<Object> modify(@RequestBody @Valid CountersignModifyReq request) {
        countersignService.modify(request);
        return new Result<>(ResultCode.SUCCESS);
    }

    @ApiOperation(value = "审核会签对象", position = 30)
    @PostMapping(value = "/approve")
    public Result<Object> approve(@RequestBody @Valid CountersignApproveReq request) {
        countersignService.approve(request);
        return new Result<>(ResultCode.SUCCESS);
    }

    @ApiOperation(value = "查询会签对象", position = 40)
    @PostMapping("/detail/{id}")
    public Result<Countersign> detail(@PathVariable("id") @Valid Integer id) {
        return new Result<>(ResultCode.SUCCESS, countersignService.detail(id));
    }

    @ApiOperation(value = "分页条件查询会签", position = 50)
    @PostMapping(value = "/page")
    public Result<PageInfo<Countersign>> page(@RequestBody @Valid CountersignPageReq request) {
        return new Result<>(ResultCode.SUCCESS, countersignService.page(request));
    }

    @ApiOperation(value = "列表条件查询会签", position = 70)
    @PostMapping(value = "/list")
    public Result<List<Countersign>> list(@RequestBody @Valid CountersignListReq request) {
        return new Result<>(ResultCode.SUCCESS, countersignService.list(request));
    }

}