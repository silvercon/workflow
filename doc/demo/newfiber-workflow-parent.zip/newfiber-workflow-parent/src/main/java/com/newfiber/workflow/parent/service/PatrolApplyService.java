package com.newfiber.workflow.parent.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.newfiber.core.result.PageInfo;
import com.newfiber.workflow.parent.entity.PatrolApply;
import com.newfiber.workflow.parent.entity.request.PatrolApplyApproveReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyCreateReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyListReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyModifyReq;
import com.newfiber.workflow.parent.entity.request.PatrolApplyPageReq;
import java.util.List;

/**
 * 巡查申请Service
 *
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
public interface PatrolApplyService extends IService<PatrolApply> {

    /**
     * 新增巡查申请
     *
     * @param req 新增巡查申请入参
     */
    void create(PatrolApplyCreateReq req);

    /**
     * 删除巡查申请
     *
     * @param id 主键ID
     */
     void remove(Integer id);

    /**
     * 修改巡查申请
     *
     * @param req 修改巡查申请入参
     */
    void modify(PatrolApplyModifyReq req);

    /**
     * 审核巡查申请
     *
     * @param req 审核巡查申请
     */
    void approve(PatrolApplyApproveReq req);

    /**
     * 详情查询巡查申请
     *
     * @param id 主键ID
     * @return 巡查申请详情数据
     */
     PatrolApply detail(Integer id);

    /**
     * 分页查询巡查申请
     *
     * @param req 分页查询巡查申请入参
     * @return 巡查申请分页数据
     */
    PageInfo<PatrolApply> page(PatrolApplyPageReq req);

    /**
     * 列表查询巡查申请
     *
     * @param req 列表查询巡查申请入参
     * @return 巡查申请列表数据
     */
     List<PatrolApply> list(PatrolApplyListReq req);

}