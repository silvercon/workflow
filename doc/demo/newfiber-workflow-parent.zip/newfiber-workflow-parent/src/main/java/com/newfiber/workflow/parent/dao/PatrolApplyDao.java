package com.newfiber.workflow.parent.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.newfiber.workflow.parent.entity.PatrolApply;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

/**
 * 巡查申请Mapper
 *
 * @author : xiongk
 * @since : 2021-08-11 09:49
 */
@Mapper
public interface PatrolApplyDao extends BaseMapper<PatrolApply>{

    /**
     * 根据条件查询
     *
     * @param condition 查询条件
     * @return 巡查申请列表
     */
    List<PatrolApply> selectByCondition(PatrolApply condition);

}