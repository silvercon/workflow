package com.newfiber.workflow.parent.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.newfiber.core.result.PageInfo;
import com.newfiber.workflow.parent.entity.Countersign;
import com.newfiber.workflow.parent.entity.request.CountersignApproveReq;
import com.newfiber.workflow.parent.entity.request.CountersignCreateReq;
import com.newfiber.workflow.parent.entity.request.CountersignListReq;
import com.newfiber.workflow.parent.entity.request.CountersignModifyReq;
import com.newfiber.workflow.parent.entity.request.CountersignPageReq;
import java.util.List;

/**
 * 会签Service
 *
 * @author : xiongk
 * @since : 2021-08-23 09:52
 */
public interface CountersignService extends IService<Countersign> {

    /**
     * 新增会签
     *
     * @param req 新增会签入参
     */
    void create(CountersignCreateReq req);

    /**
     * 删除会签
     *
     * @param id 主键ID
     */
     void remove(Integer id);

    /**
     * 修改会签
     *
     * @param req 修改会签入参
     */
    void modify(CountersignModifyReq req);

    /**
     * 审核会签
     *
     * @param req 审核巡查申请
     */
    void approve(CountersignApproveReq req);

    /**
     * 详情查询会签
     *
     * @param id 主键ID
     * @return 会签详情数据
     */
     Countersign detail(Integer id);

    /**
     * 分页查询会签
     *
     * @param req 分页查询会签入参
     * @return 会签分页数据
     */
    PageInfo<Countersign> page(CountersignPageReq req);

    /**
     * 列表查询会签
     *
     * @param req 列表查询会签入参
     * @return 会签列表数据
     */
     List<Countersign> list(CountersignListReq req);

}