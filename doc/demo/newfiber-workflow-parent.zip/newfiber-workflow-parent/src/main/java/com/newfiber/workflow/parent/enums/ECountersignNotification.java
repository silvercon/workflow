package com.newfiber.workflow.parent.enums;

import com.newfiber.workflow.support.notification.IWorkflowEmailNotification;
import com.newfiber.workflow.support.notification.IWorkflowSmsNotification;

public enum ECountersignNotification
    implements IWorkflowEmailNotification, IWorkflowSmsNotification {
  /** */
  AfterApprove("AfterApprove", "[%s]您有一条待办任务:[%s],请在[%s]前完成", "新钜物联", "1094534");
  ;

  private final String notificationTask;

  private final String notificationTemplate;

  private final String smsSign;

  private final String smsTemplateCode;

  ECountersignNotification(
      String notificationTask,
      String notificationTemplate,
      String smsSign,
      String smsTemplateCode) {
    this.notificationTask = notificationTask;
    this.notificationTemplate = notificationTemplate;
    this.smsSign = smsSign;
    this.smsTemplateCode = smsTemplateCode;
  }

  @Override
  public String getNotificationTask() {
    return notificationTask;
  }

  @Override
  public String getNotificationTemplate() {
    return notificationTemplate;
  }

  @Override
  public String getSmsSign() {
    return smsSign;
  }

  @Override
  public String getSmsTemplateCode() {
    return smsTemplateCode;
  }
}

// public enum ECountersignNotification implements IWorkflowEmailNotification {
//    /**
//     *
//     */
//    AfterApprove("AfterApprove", "[%workflowKey]您有一条待办任务:[%businessKey],请在[%dueDate]前完成");
//    ;
//
//    private final String notificationTask;
//
//    private final String notificationTemplate;
//
//    ECountersignNotification(String notificationTask, String notificationTemplate) {
//        this.notificationTask = notificationTask;
//        this.notificationTemplate = notificationTemplate;
//    }
//
//    @Override
//    public String getNotificationTask() {
//        return notificationTask;
//    }
//
//    @Override
//    public String getNotificationTemplate() {
//        return notificationTemplate;
//    }
// }

// public enum ECountersignNotification implements IWorkflowSmsNotification {
//    /**
//     *
//     */
//    AfterApprove("AfterApprove", "新钜物联","219220106");
//    ;
//
//    private final String notificationTask;
//
//    private final String smsSign;
//
//    private final String smsTemplateCode;
//
//    ECountersignNotification(String notificationTask, String smsSign, String smsTemplateCode) {
//        this.notificationTask = notificationTask;
//        this.smsSign = smsSign;
//        this.smsTemplateCode = smsTemplateCode;
//    }
//
//    @Override
//    public String getNotificationTask() {
//        return notificationTask;
//    }
//
//    @Override
//    public String getSmsSign() {
//        return smsSign;
//    }
//
//    @Override
//    public String getSmsTemplateCode() {
//        return smsTemplateCode;
//    }
//
// }
