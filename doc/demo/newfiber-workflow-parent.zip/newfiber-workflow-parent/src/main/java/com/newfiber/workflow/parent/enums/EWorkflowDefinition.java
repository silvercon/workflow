package com.newfiber.workflow.parent.enums;

import com.newfiber.workflow.support.IWorkflowDefinition;

public enum EWorkflowDefinition implements IWorkflowDefinition {
    /**
     *
     */
    PatrolApply("PatrolApply", "巡查申请", "t", Integer.class),
    Countersign("Countersign", "会签", "t", Integer.class)
    ;

    EWorkflowDefinition(String workflowKey, String workflowName, String tableName,
            Class<?> tableIdType) {
        this.workflowKey = workflowKey;
        this.workflowName = workflowName;
        this.tableName = tableName;
        this.tableIdType = tableIdType;
    }

    private final String workflowKey;

    private final String workflowName;

    private final String tableName;

    private final Class<?> tableIdType;

    @Override
    public String getWorkflowKey() {
        return workflowKey;
    }

    @Override
    public String getWorkflowName() {
        return workflowName;
    }

    @Override
    public String getTableName() {
        return tableName;
    }

    @Override
    public Class<?> getTableIdType() {
        return tableIdType;
    }

}
