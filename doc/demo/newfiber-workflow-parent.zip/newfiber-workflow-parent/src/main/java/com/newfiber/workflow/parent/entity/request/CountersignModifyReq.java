package com.newfiber.workflow.parent.entity.request;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * 修改会签
 *
 * @author : xiongk
 * @since : 2021-08-23 09:52
 */
@Data
public class CountersignModifyReq {

    /**
     * 编号
     */
    @NotNull(message = "id不能为空")
    @ApiModelProperty(name = "id", value = "编号")
    private Integer id;

    /**
     * 申请说明
     */
    @ApiModelProperty(name = "applyNote", value = "申请说明")
    private String applyNote;


}
