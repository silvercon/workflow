package com.newfiber.workflow.parent.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.newfiber.workflow.parent.entity.Countersign;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

/**
 * 会签Mapper
 *
 * @author : xiongk
 * @since : 2021-08-23 09:52
 */
@Mapper
public interface CountersignDao extends BaseMapper<Countersign>{

    /**
     * 根据条件查询
     *
     * @param condition 查询条件
     * @return 会签列表
     */
    List<Countersign> selectByCondition(Countersign condition);

}