package com.newfiber.workflow.parent;

import com.newfiber.workflow.utils.NotificationService;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkflowParentApplicationTests {

  @Resource private NotificationService notificationService;

  @Test
  void contextLoads() {}

  @Test
  void emailTest() {
    notificationService.sendSimpleMail("591495892@qq.com", "测试", "测试");
  }

  @Test
  void smsTest() {
    List<String> templateArgs = new ArrayList<>();
    templateArgs.add("会签");
    templateArgs.add("12");
    templateArgs.add("2021-09-01");
    notificationService.sendTencentSms("18772346904", "新钜物联", "1094333", templateArgs);
  }
}
