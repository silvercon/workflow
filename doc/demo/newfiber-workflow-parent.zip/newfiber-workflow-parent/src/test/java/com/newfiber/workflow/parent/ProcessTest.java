package com.newfiber.workflow.parent;

import com.newfiber.workflow.entity.WorkflowHistoricActivity;
import com.newfiber.workflow.service.ActivitiProcessService;
import java.util.List;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author : X.K
 * @since : 2022/1/26 下午5:59
 */
@Slf4j
@SpringBootTest
public class ProcessTest {

	@Resource
	private ActivitiProcessService activitiProcessService;

	@Test
	public void historyCommentTest(){

		List<WorkflowHistoricActivity> workflowHistoricActivityList = activitiProcessService.
			listHistoricActivity("QiLiHeInspectionSubFlow", "1486222588956143618", "", "");

		log.info("1");
	}
}
