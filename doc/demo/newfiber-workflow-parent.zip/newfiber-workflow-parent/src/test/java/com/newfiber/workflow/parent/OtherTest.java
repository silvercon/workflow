package com.newfiber.workflow.parent;


import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

public class OtherTest {

    @Test
    void otherTest(){
        List<String> notificationTemplateArgs = new ArrayList<>();
        notificationTemplateArgs.add("1");
        notificationTemplateArgs.add("2");
        notificationTemplateArgs.add("3");
        String content = String.format("[%s]您有一条待办任务:[%s],请在[%s]前完成", notificationTemplateArgs.toArray());
        System.out.println(content);
    }
}
