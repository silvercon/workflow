DROP TABLE IF EXISTS `biz_patrol_apply`;
CREATE TABLE `biz_patrol_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `workflow_instance_id` varchar(255) DEFAULT NULL COMMENT '工作流实例编号',
  `status` varchar(32) DEFAULT NULL COMMENT '状态',
  `apply_note` varchar(255) DEFAULT NULL COMMENT '申请说明',
  `apply_datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='管网巡查申请';

DROP TABLE IF EXISTS `biz_purchase_apply`;
CREATE TABLE `biz_purchase_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `workflow_instance_id` varchar(255) DEFAULT NULL COMMENT '工作流实例编号',
  `apply_user_id` varchar(32) NOT NULL COMMENT '申请人编号',
  `status` varchar(32) DEFAULT NULL COMMENT '状态',
  `apply_note` varchar(255) NOT NULL COMMENT '申请说明',
  `apply_datetime` datetime NOT NULL COMMENT '申请时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='采购申请';
